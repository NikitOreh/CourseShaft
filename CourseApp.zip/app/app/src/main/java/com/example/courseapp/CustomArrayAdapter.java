package com.example.courseapp;

import android.view.LayoutInflater;
import android.widget.ArrayAdapter;

import java.util.ArrayList;

public class CustomArrayAdapter extends ArrayAdapter<ListItemClass> {
    private LayoutInflater inflater;
    private List<ListItemClass> listItem = new ArrayList<>();
    
}
